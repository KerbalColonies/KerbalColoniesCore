# v1.0.2
- Reworked the storage facility to only show available resources
- Added this changelog with minimal markdown support
- Added the missing license file to release

# v1.0.1
- Seperated the facility configs into their own mod to allow easier replacement in the future
- Added options to rename facilities and colonies

# v1.0.0
- Initial release